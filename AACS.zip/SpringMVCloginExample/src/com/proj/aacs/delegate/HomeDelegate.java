package com.proj.aacs.delegate;

import java.sql.SQLException;

import org.json.JSONArray;

import com.proj.aacs.service.HomeService;

public class HomeDelegate
{
		private HomeService homeService;

		public HomeService getHomeService() {
			return homeService;
		}

		public void setHomeService(HomeService homeService) {
			this.homeService = homeService;
		}

		public JSONArray getProjectList() throws SQLException
    {
		    return homeService.getProjectList();
    }
}
