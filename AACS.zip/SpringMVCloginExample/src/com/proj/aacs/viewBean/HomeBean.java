package com.proj.aacs.viewBean;

public class HomeBean
{
		private String projectId;

		private String projectName;

		private String projectDesc;
		
		private String projectSkills;

		public HomeBean(String projectId, String projectName, String projectDesc, String projectSkills) {
			super();
			this.projectId = projectId;
			this.projectName = projectName;
			this.projectDesc = projectDesc;
			this.projectSkills = projectSkills;
		}

		public HomeBean() {
		}

		public String getProjectId() {
			return projectId;
		}

		public void setProjectId(String projectId) {
			this.projectId = projectId;
		}

		public String getProjectName() {
			return projectName;
		}

		public void setProjectName(String projectName) {
			this.projectName = projectName;
		}

		public String getProjectDesc() {
			return projectDesc;
		}

		public void setProjectDesc(String projectDesc) {
			this.projectDesc = projectDesc;
		}

		public String getProjectSkills() {
			return projectSkills;
		}

		public void setProjectSkills(String projectSkills) {
			this.projectSkills = projectSkills;
		}

		
}
