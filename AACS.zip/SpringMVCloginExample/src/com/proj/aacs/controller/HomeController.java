package com.proj.aacs.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.proj.aacs.delegate.HomeDelegate;
import com.proj.aacs.viewBean.HomeBean;


@Controller
public class HomeController
{
		@Autowired
		private HomeDelegate homeDelegate;

		@RequestMapping(value="/home",method=RequestMethod.POST)
		public ModelAndView executeHome(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("homeBean")HomeBean homeBean)
		{
				ModelAndView model= null;
				try
				{
						JSONArray jArr = homeDelegate.getProjectList();
						if(jArr!=null)
						{
								System.out.println("List of Projects: "+ homeDelegate.getProjectList());
								request.setAttribute("ProjectList", homeDelegate.getProjectList());
								model = new ModelAndView("welcome");
						}

				}
				catch(Exception e)
				{
						e.printStackTrace();
				}

				return model;
		}
}
