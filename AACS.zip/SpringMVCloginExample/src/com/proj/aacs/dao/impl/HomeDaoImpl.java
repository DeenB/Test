package com.proj.aacs.dao.impl;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.proj.aacs.dao.HomeDao;


/**
 * @author CENTAUR
 */
public class HomeDaoImpl implements HomeDao
{

		DataSource dataSource;

		public DataSource getDataSource()
		{
				return this.dataSource;
		}

		public void setDataSource(DataSource dataSource)
		{
				this.dataSource = dataSource;
		}

		@Override
		public JSONArray getProjectList() throws SQLException
		{
			JSONArray jArr = new JSONArray();
				String query = "Select * from project";
				PreparedStatement pstmt = dataSource.getConnection().prepareStatement(query);
				ResultSet resultSet = pstmt.executeQuery();
				while (resultSet.next()){
					JSONObject jObj = new JSONObject();
					try {
						jObj.put("id", resultSet.getInt(1));
						jObj.put("id", resultSet.getString(1));
						jObj.put("id", resultSet.getInt(1));
						jObj.put("id", resultSet.getInt(1));
						jArr.put(jObj);
					} catch (JSONException e) {
						e.printStackTrace();
					}
					
				}
				return jArr;
		}

}