package com.proj.aacs.dao;

import java.sql.SQLException;

import org.json.JSONArray;

/**
 * @author CENTAUR
 * This interface will be used to communicate with the
 * Database
 */
public interface HomeDao
{
		public JSONArray getProjectList() throws SQLException;
}
