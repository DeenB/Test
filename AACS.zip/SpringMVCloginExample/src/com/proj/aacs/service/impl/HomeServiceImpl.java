package com.proj.aacs.service.impl;

import java.sql.SQLException;

import org.json.JSONArray;

import com.proj.aacs.dao.HomeDao;
import com.proj.aacs.service.HomeService;

public class HomeServiceImpl implements HomeService
{

		private HomeDao homeDao;

		public HomeDao getHomeDao() {
			return homeDao;
		}

		public void setHomeDao(HomeDao homeDao) {
			this.homeDao = homeDao;
		}


		@Override
		public JSONArray getProjectList() throws SQLException
		{
				return homeDao.getProjectList();
		}

}
