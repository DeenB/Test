/**
 *
 */
package com.proj.aacs.service;

import java.sql.SQLException;

import org.json.JSONArray;

/**
 * @author CENTAUR
 *
 */
public interface HomeService
{
		public JSONArray getProjectList() throws SQLException;
}
